echo "Install depencency for cgminer ->"
echo "*********************************************"
sudo chmod 777 -R ./*
sudo cp ./dep/* /usr/lib/
echo "*********************************************"
echo "Install depencency for cgminer Done!"