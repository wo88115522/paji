echo  "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo  "     CG MINER - BITCOINFINANCE(BTF) NETWORK "
echo  "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "Checked if all lib available..."
echo  "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
ldd ./cgminer
echo "If none lib available pls run ./install_dependency.sh"
echo  "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "Usage Example1:   sudo ./cgminer -o stratum+tcp://jp.bitforcepool.com:3333 -u 1Q2LUmeKqyfikSDeku1SrAU7xM19jyUdNe.6700 -p BTF"
echo  "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "Usage Example2:   sudo ./cgminer  --config  ./cgminer.conf"
echo  "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "But before using cgminer you should install CUDA , drivers , cudnn, Opencl First!"
echo "Checking CL device - >"
echo  "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
./cgminer -n
echo " Next -/- ->"
echo "Checking CGMINER VERSION - >"
echo  "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
./cgminer  --version
echo  "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "START CGMINER - >"
echo  "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
sudo ./cgminer --config ./cgminer.conf
#sudo ./cgminer --url  stratum+tcp://asia.bitforcepool.com:3333  --user  1Q2LUmeKqyfikSDeku1SrAU7xM19jyUdNe.6700 --pass  BTF